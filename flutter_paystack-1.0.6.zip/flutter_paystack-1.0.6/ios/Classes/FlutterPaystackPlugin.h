#import <Flutter/Flutter.h>

@interface FlutterPaystackPlugin : NSObject<FlutterPlugin>
@end
