extension MyString on String {
  Uri toUri() => Uri.parse(this);
}
