class ApiResponse {
  String? status;
  String? message;
}
