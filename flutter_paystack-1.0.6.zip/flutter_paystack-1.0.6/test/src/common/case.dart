class Case {
  dynamic inp;
  dynamic out;
  String? desc;

  Case({required this.inp, required this.out, this.desc});
}
