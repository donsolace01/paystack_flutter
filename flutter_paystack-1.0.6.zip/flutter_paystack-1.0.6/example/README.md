# flutter_paystack_example

Demonstrates how to use the flutter_paystack plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
