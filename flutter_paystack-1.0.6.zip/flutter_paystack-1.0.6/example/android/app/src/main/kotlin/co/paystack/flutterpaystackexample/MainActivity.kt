package co.paystack.flutterpaystackexample

import io.flutter.embedding.android.FlutterActivity


class MainActivity: FlutterActivity()